# adds MAF column to plink output (needed for mtag)

#.frq file generated from plink
frqName = "/u/scratch/c/cmhuang/plink_150k.frq"
plinkdir = "/u/scratch/c/cmhuang/data_ukbb_other_traits/ukbb_gwas_ss_plink_wSE_linear_150k_A2"
outdir = "/u/scratch/c/cmhuang/data_ukbb_other_traits/ukbb_gwas_ss_plink_wSE_linear_150k_MAF"
listFile = "/u/scratch/c/cmhuang/data_ukbb_other_traits/ukbb_gwas_ss_plink_wSE_linear_150k_A2/plink_assoc_150k_A2_list.txt"

frqD = {} # frq[(chro, pos)] = MAF
with open(frqName) as frqf:
    for line in frqf:
        lineL = line.rstrip().split()
        chro = lineL[0]
        SNP = lineL[1]
        frq = lineL[4]
        frqD[(chro,SNP)] = frq

# get list of gwas files that need conversion
with open(listFile) as f:
    fileL = [x.rstrip() for x in f.readlines()]

for fname in fileL:
    plinkName = "%s/%s" % (plinkdir, fname)
    outName = "%s/%s_MAF" % (outdir, fname)
    with open(plinkName) as plinkf:
        with open(outName, 'w') as outf:
            header = plinkf.readline() # skip header
            outf.write(header.rstrip() + "\tMAF\n")
            for line in plinkf:
                lineL = line.rstrip().split()
                chro = lineL[0]
                SNP = lineL[1]
                outline = line.rstrip() + "\t" + frqD[(chro,SNP)] + "\n"
                outf.write(outline)

    print('added frq to %s' % plinkName)


