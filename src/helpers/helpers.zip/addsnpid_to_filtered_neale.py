#adds chr:bp (snpid) column to filtered neale file

nealedir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/filtered_both_filters"
outdir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/filtered_both_filters"
listFile = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/filtered_both_filters/filtered_traits.txt"

# get list of gwas files that need conversion
with open(listFile) as f:
    fileL = [x.rstrip() for x in f.readlines()]

for fname in fileL:
    nealeName = "%s/%s.neale_indivs.assoc.linear.formatted" % (nealedir, fname)
    outName = "%s/%s.neale_indivs.assoc.linear.formatted_snpid" % (outdir, fname)
    with open(nealeName) as nealef:
        with open(outName, 'w') as outf:
            header = nealef.readline() # skip header
            outf.write(header.rstrip() + "\tsnpid\n")
            for line in nealef:
                lineL = line.rstrip().split()
                chro = lineL[7]
                SNP = lineL[7] + ':' + lineL[8]
                outline = line.rstrip() + "\t" + SNP + "\n"
                outf.write(outline)

    print('added snpid to %s' % nealeName)


