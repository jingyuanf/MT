# adds A2 allele column to plink output (both ref and alt allele required by LDSC)
# for future reference, plink may have an option to keep both alleles (e.g. if A ref G alt should be treated differently as G ref A alt, there's some option to handle that)


nealedir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/MT_estimates_neale_filtered/"
outdir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/MT_estimates_neale_filtered"
listFile = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/MT_estimates_neale_filtered/MT_list.txt"

# get list of gwas files that need conversion
with open(listFile) as f:
    fileL = [x.rstrip() for x in f.readlines()]

# assumes alleles in plinkf are subset of those in bimf
for fname in fileL:
    nealeName = "%s/%s.assoc.MTAG.MT_estimates" % (nealedir, fname)
    outName = "%s/%s.assoc.MTAG.MT_estimates_snpid" % (outdir, fname)
    with open(nealeName) as nealef:
        with open(outName, 'w') as outf:
            header = nealef.readline() # skip header
            outf.write(header.rstrip() + "\tsnpid\n")
            for line in nealef:
                lineL = line.rstrip().split()
                chro = lineL[2]
                SNP = lineL[2] + ':' + lineL[3]
                outline = line.rstrip() + "\t" + SNP + "\n"
                outf.write(outline)

    print('added snpid to %s' % nealeName)


