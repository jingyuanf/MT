# adds snpid (chr:bp) column to neale gwas (after first reformatting, to avoid clashing with rsID for certain software (ie mtag))

nealedir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/new_reformatted"
outdir = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/new_reformatted"
listFile = "/u/scratch/c/cmhuang/UKB_Neale_round1_sep2017/neale_list.txt"

# get list of gwas files that need conversion
with open(listFile) as f:
    fileL = [x.rstrip() for x in f.readlines()]

for fname in fileL:
    #reformatted file names
    nealeName = "%s/reformatted_%s" % (nealedir, fname)
    outName = "%s/reformatted_snpid_%s" % (outdir, fname)
    with open(nealeName) as nealef:
        with open(outName, 'w') as outf:
            header = nealef.readline() # skip header
            outf.write(header.rstrip() + "\tsnpid\n")
            for line in nealef:
                lineL = line.rstrip().split()
                chro = lineL[9]
                #chr:bpos
                SNP = lineL[9] + ':' + lineL[10]
                outline = line.rstrip() + "\t" + SNP + "\n"
                outf.write(outline)

    print('added snpid to %s' % nealeName)


